# 🎭 表演与微表情 Skill
> 来源：《演员自我修养》斯坦尼斯拉夫斯基 + 《微表情》保罗·艾克曼

---

## 📐 七种基本情绪

保罗·艾克曼发现人类有七种**跨文化通用**的基本情绪：

| 情绪 | 面部特征 | AI Prompt |
|------|----------|-----------|
| 😊 **快乐** | 嘴角上扬，眼角皱纹 | smiling, joyful expression, crows feet |
| 😢 **悲伤** | 眉毛内侧上扬，嘴角下垂 | sad eyes, downturned mouth, teary |
| 😠 **愤怒** | 眉毛下压，嘴唇紧闭 | furrowed brow, clenched jaw, fierce eyes |
| 😨 **恐惧** | 眉毛上扬，眼睛睁大 | wide eyes, raised eyebrows, tense |
| 😲 **惊讶** | 眉毛上扬，嘴巴张开 | wide eyes, open mouth, shocked |
| 🤢 **厌恶** | 鼻子皱起，上唇上扬 | wrinkled nose, curled lip, disgusted |
| 😤 **蔑视** | 嘴角一侧上扬 | one-sided smirk, dismissive look |

---

## 🎯 表情细节分解

### 快乐 (Happiness)
| 程度 | 特征 | AI描述 |
|------|------|--------|
| 微笑 | 嘴角轻微上扬 | gentle smile, soft expression |
| 高兴 | 嘴角上扬+眼睛弯曲 | genuine smile, happy eyes |
| 大笑 | 嘴巴张开，眼睛眯起 | laughing, joyful, beaming |
| 狂喜 | 整个面部明亮 | ecstatic, radiant joy |

### 悲伤 (Sadness)
| 程度 | 特征 | AI描述 |
|------|------|--------|
| 忧郁 | 眼神低落 | melancholic, wistful look |
| 难过 | 眉头轻皱，嘴角下垂 | sad, downcast expression |
| 哭泣 | 流泪，面部扭曲 | crying, tears streaming |
| 崩溃 | 无法控制的抽泣 | sobbing, devastated |

### 愤怒 (Anger)
| 程度 | 特征 | AI描述 |
|------|------|--------|
| 不悦 | 眉头轻皱 | annoyed, displeased |
| 生气 | 眉头紧锁，嘴唇绷紧 | angry, tense jaw |
| 暴怒 | 眼睛圆睁，面部涨红 | furious, raging, veins visible |

### 恐惧 (Fear)
| 程度 | 特征 | AI描述 |
|------|------|--------|
| 担忧 | 眉头轻皱 | worried, concerned |
| 害怕 | 眼睛睁大，嘴唇分开 | scared, fearful expression |
| 恐惧 | 面色苍白，身体僵硬 | terrified, frozen in fear |
| 惊恐 | 尖叫表情 | horrified, screaming |

---

## 🎬 复合情绪

真实的情绪常常是**混合的**：

| 复合情绪 | 组成 | AI描述 |
|----------|------|--------|
| 苦笑 | 悲伤+快乐 | bittersweet smile, sad smile |
| 嫉妒 | 愤怒+悲伤 | jealous look, envious |
| 羞愧 | 恐惧+悲伤 | ashamed, embarrassed, looking down |
| 骄傲 | 快乐+蔑视 | proud, chin up, confident smile |
| 敬畏 | 恐惧+惊讶 | awestruck, amazed |
| 紧张 | 恐惧+期待 | nervous, anxious anticipation |

---

## 🧠 潜台词表演

### 斯坦尼斯拉夫斯基表演法
**关键**：角色说的话不一定是心里想的

| 表面 | 潜台词 | 表演要点 |
|------|--------|----------|
| "我很好" | 其实很难过 | 眼神闪避，声音勉强 |
| "随便" | 很在意 | 身体紧绷，表情僵硬 |
| "我不在乎" | 非常在乎 | 刻意冷漠，但有破绽 |

### AI分镜应用
描述角色时，注明：
1. **说的话**
2. **真实情感**
3. **面部表情**
4. **肢体语言**

---

## 💪 肢体语言

### 情绪-肢体对照

| 情绪 | 肢体特征 | AI描述 |
|------|----------|--------|
| 自信 | 挺胸抬头，占据空间 | standing tall, confident posture |
| 紧张 | 身体收缩，小动作多 | hunched, fidgeting, crossed arms |
| 悲伤 | 肩膀下垂，目光低垂 | slumped shoulders, looking down |
| 愤怒 | 身体前倾，拳头紧握 | leaning forward, clenched fists |
| 防御 | 双臂交叉，身体后仰 | arms crossed, leaning back |
| 开放 | 双手张开，身体前倾 | open arms, leaning in |

### 眼神方向
| 方向 | 含义 |
|------|------|
| 直视 | 坦诚、挑战、连接 |
| 向下 | 羞愧、悲伤、思考 |
| 向上 | 回忆、思考、祈祷 |
| 左右闪躲 | 撒谎、不安、寻找 |
| 空洞 | 创伤、绝望、分离 |

---

## 📋 角色表演设计模板

```
【角色情感设计】

角色：[名字]
场景：[描述]
对白："[台词]"

表面情感：[说出来的]
真实情感：[内心的]
潜台词：[没说出来的]

面部表情：
- 眼睛：[描述]
- 眉毛：[描述]
- 嘴巴：[描述]

肢体语言：
- 姿势：[描述]
- 手势：[描述]
- 动作：[描述]

AI Prompt关键词：
[整合上述描述]
```

---

## 🎯 表情AI Prompt词汇库

### 眼神
| 中文 | AI Prompt |
|------|-----------|
| 坚定 | determined eyes, resolute gaze |
| 温柔 | soft eyes, gentle gaze |
| 冷酷 | cold eyes, icy stare |
| 空洞 | vacant stare, hollow eyes |
| 渴望 | longing eyes, yearning look |
| 戒备 | wary eyes, cautious look |
| 狡黠 | cunning eyes, sly look |

### 整体表情
| 中文 | AI Prompt |
|------|-----------|
| 若有所思 | pensive, contemplative |
| 心事重重 | troubled expression, worried |
| 如释重负 | relieved, weight lifted |
| 目瞪口呆 | stunned, jaw dropped |
| 不寒而栗 | shuddering, chilled |
| 欲言又止 | hesitant, words caught |
| 强颜欢笑 | forced smile, pretending |

---

*Skill版本: 1.0*
*来源: 《演员自我修养》《微表情》*
*创建时间: 2026-02-14*
